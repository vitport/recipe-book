# 🏗️ Architecture Document
**My Recipe Book | Technical Architecture**
*Zeev & Vitaly | April 2026*

---

## 1. System Overview

```
┌─────────────────────────────────────────────────────────┐
│                    CLIENT DEVICES                        │
│  PC Browser      Mobile Browser    Tablet Browser        │
│  localhost:8080  192.168.1.2:8080  192.168.1.2:8080     │
└──────────────────────────┬──────────────────────────────┘
                           │ HTTP
┌──────────────────────────▼──────────────────────────────┐
│              NODE.JS EXPRESS SERVER (:8080)              │
│                                                          │
│  Static Files    API Routes      Proxy Routes            │
│  index.html      /recipes.json   /api/ollama/*           │
│  test.html       /save-recipes   /api/proxy-image        │
│  favicon.svg                                             │
└──────┬───────────────────────────────┬───────────────────┘
       │ File I/O                      │ HTTP
┌──────▼──────────┐        ┌──────────▼──────────────────┐
│  recipes.json   │        │   OLLAMA SERVER (:11434)     │
│  server.log     │        │                              │
│  (flat file DB) │        │   mistral:latest (7B)        │
└─────────────────┘        │   4.4GB model                │
                           │   ~5GB RAM when active       │
                           └──────────────────────────────┘
```

---

## 2. Frontend Architecture (index.html)

### Single File Architecture
The entire frontend lives in one HTML file (~1700 lines).
This was a deliberate choice for simplicity and portability.

```
index.html
├── <head>
│   ├── CSS styles (inline)
│   ├── External CDN libraries
│   │   ├── PDF.js 3.11.174
│   │   ├── jsPDF 2.5.1
│   │   └── Tesseract.js (OCR)
│   └── Favicon link
├── <body>
│   ├── Header (search bar, title)
│   ├── Filter pills (dish type, kosher type)
│   ├── Recipe cards grid
│   ├── Modals
│   │   ├── #m-add (Add recipe)
│   │   ├── #m-view (View recipe)
│   │   ├── #m-editor (Edit recipe)
│   │   ├── #m-image-picker (Image selection)
│   │   └── #m-photo-mgr (Photo manager)
│   └── Toast notifications
└── <script>
    ├── State Management
    │   ├── recipes[] array
    │   ├── filters object
    │   └── sortMode string
    ├── Core Functions
    │   ├── render() — rebuild recipe grid
    │   ├── saveRecipe() — add/edit recipe
    │   ├── delR(id) — delete recipe
    │   └── syncToServer() — POST to /save-recipes
    ├── Import Functions
    │   ├── fetchURL() — URL import with proxy
    │   ├── handleFile() — text file import
    │   ├── handlePDF() — PDF text extraction
    │   ├── runOCR() — photo to text
    │   └── parseRecipeText() — manual parser
    ├── AI Functions
    │   ├── ollamaParseRecipe() — Mistral parsing
    │   ├── extractImagesFromHTML() — find images
    │   ├── pickImagesFromURL() — AI image selection
    │   ├── downloadImageAsBase64() — fetch image
    │   └── releaseOllama() — free RAM
    ├── Photo Manager
    │   ├── openPhotoMgr() — open popup
    │   ├── renderPhotoMgr() — render grid
    │   ├── pmSetMain(i) — set main photo
    │   ├── pmMove(i, dir) — reorder
    │   └── pmDelete(i) — remove photo
    ├── Export Functions
    │   ├── exportJSON() — download JSON
    │   ├── exportRecipePDF(id) — beautiful PDF
    │   └── importJSON() — import from file
    └── Utility Functions
        ├── detectLang(text) — he/en/ru detection
        ├── hl(text, query) — search highlighting
        ├── toast(msg) — notifications
        └── setF(type, val) — set filter
```

---

## 3. Backend Architecture (server.js)

### Express Server
```javascript
// Middleware
- express.json() — parse JSON bodies
- express.static() — serve static files
- Request logger → server.log

// Routes
GET  /                      → index.html
GET  /recipes.json          → read recipes file
POST /save-recipes          → write recipes file
GET  /api/ollama/status     → check Ollama health
POST /api/ollama/generate   → proxy to Mistral
POST /api/ollama/release    → release model RAM
GET  /api/proxy-image       → download image server-side
```

### Request Flow — Recipe Save
```
Browser → POST /save-recipes {recipes: [...]}
    → server.js validates JSON
    → fs.writeFileSync('recipes.json', JSON)
    → Response: {success: true}
Browser → shows "Saved ✓" toast
```

### Request Flow — AI Parsing
```
Browser → POST /api/ollama/generate {prompt: "..."}
    → server.js forwards to localhost:11434/api/generate
    → Mistral processes (up to 180s)
    → Response: {response: "...JSON..."}
Browser → extractJSON() parses response
    → fills recipe fields
```

---

## 4. Data Architecture

### Recipe Schema
```json
{
  "id": "1745678901234",
  "name": "מתכון לגולש",
  "description": "גולאש קל להכנה...",
  "language": "he",
  "dishType": "dinner",
  "kosherType": "meat",
  "cookingTime": 120,
  "servings": 8,
  "ingredients": [
    "1 ק\"ג בשר צלי כתף",
    "3 בצלים גדולים"
  ],
  "instructions": [
    "מחממים שמן במחבת",
    "מטגנים בצל עד להזהבה"
  ],
  "photos": [
    "data:image/jpeg;base64,/9j/4AAQ..."
  ],
  "sourceUrl": "https://www.10dakot.co.il/...",
  "createdAt": "2026-04-22T10:00:00.000Z",
  "updatedAt": "2026-04-23T15:30:00.000Z"
}
```

### Storage Strategy
- **Primary**: recipes.json (flat file, server-side)
- **Cache**: localStorage (browser-side, per device)
- **Sync**: POST /save-recipes on every mutation
- **Backup**: Export JSON button

---

## 5. AI Architecture

### Ollama Integration
```
index.html
    → POST /api/ollama/generate (our server)
        → POST localhost:11434/api/generate (Ollama)
            → Mistral 7B processes
        → Returns raw text response
    → extractJSON() normalizes response
    → toArr() handles array/string variants
    → Fills recipe fields
    → POST /api/ollama/release (free RAM)
```

### Mistral Prompting Strategy
- Keep prompts under 100 words
- Request minimal JSON (max 3 fields)
- Always add: "No ellipsis. No truncation."
- Use comma-separated strings, not arrays
- 180 second timeout
- 5 second cooldown between calls
- Auto-retry once on failure
- Fallback to {score:5} on JSON parse error

### Image Processing Pipeline
```
1. fetchURL() → raw HTML (935KB from 10dakot)
2. extractImagesFromHTML() → 20 candidate URLs
3. Mistral: "Which are food photos?" → food URLs
4. Mistral: "Rank best for recipe card" → ranked list
5. User selects in image picker popup
6. downloadImageAsBase64() → base64 via server proxy
7. prepend to recipe.photos[]
```

---

## 6. Security Considerations

| Risk | Mitigation |
|------|-----------|
| CORS attacks | Server-side proxy only |
| File injection | JSON validation before write |
| Path traversal | Static file serving only |
| XSS | No innerHTML with user data |
| Data loss | Auto-save + export backup |

### Current Limitations (Pre-Auth)
- No authentication (LAN only, trusted users)
- No rate limiting on API endpoints
- No input sanitization (planned for multi-user)

---

## 7. Performance Profile

| Metric | Value |
|--------|-------|
| index.html size | 92KB |
| Load time | 20ms (local) |
| Server response | 12-50ms |
| AI parsing | 5-45 seconds |
| Image download | 1-5 seconds |
| recipes.json | ~50KB (7 recipes) |

---

## 8. Future Architecture (v3.0)

```
┌─────────────────────────────────┐
│         CDN (Cloudflare)        │
└──────────────┬──────────────────┘
               │
┌──────────────▼──────────────────┐
│      Cloud Server (Railway)     │
│  Node.js + Express              │
│  Firebase Auth middleware       │
└──────┬───────────────┬──────────┘
       │               │
┌──────▼──────┐  ┌─────▼────────┐
│  Firestore  │  │   Storage    │
│  (recipes)  │  │   (images)   │
└─────────────┘  └──────────────┘
```
