# 🗺️ Product Roadmap
**My Recipe Book | Zeev & Vitaly**
*April 2026 → Future*

---

## Current Version: v2.0 ✅

**Status: Production-ready for single-user LAN**

### Completed Features
- ✅ Full recipe CRUD
- ✅ Multilingual (Hebrew/English/Russian) with RTL
- ✅ AI parsing with Mistral 7B (local)
- ✅ URL/PDF/Photo/Text import
- ✅ Image picker with Mistral food detection
- ✅ Photo manager popup
- ✅ Node.js Express server
- ✅ LAN network sharing
- ✅ 75+ AI-powered tests (100% pass rate)
- ✅ PDF export
- ✅ Sorting, filtering, search

---

## Version 2.1 — Image & Polish 🔧
**Target: Next 1-2 sessions**

| Feature | Priority | Status |
|---------|----------|--------|
| Fix image CORS via server proxy | Critical | In Progress |
| Fix Ollama memory release | High | In Progress |
| End-to-end image picker test | High | Pending |
| Fix "Best: ?" display in tests | Low | Pending |
| Add .gitignore for server.log | Low | Pending |

---

## Version 3.0 — Multi-User 👥
**Target: 3-5 sessions**

### Architecture Changes
- Move from flat file to proper database
- Add user authentication layer
- Personal recipe collections per user
- Shared family recipe pool

### Features
| Feature | Priority |
|---------|----------|
| User registration/login | Critical |
| Google OAuth | High |
| Apple Sign In | High |
| Firebase Authentication | High |
| Personal recipe collections | High |
| Shared family pool | Medium |
| Recipe sharing between users | Medium |
| User profiles | Medium |

### Technical Requirements
- Firebase Auth SDK
- Firestore or Supabase for database
- JWT session management
- User-scoped API endpoints
- Migration tool for existing recipes

---

## Version 4.0 — Social Features 🌟
**Target: Future**

| Feature | Priority |
|---------|----------|
| Recipe ratings (1-5 stars) | High |
| Comments on recipes | Medium |
| Favorites/bookmarks | High |
| Recipe collections/categories | Medium |
| Follow other cooks | Low |
| Recipe feed | Low |

---

## Version 5.0 — Cloud Deployment 🚀
**Target: Future (Step 7 of Vibe Course)**

### Infrastructure
| Component | Technology |
|-----------|-----------|
| Hosting | Railway / Render / Fly.io |
| Database | Firebase Firestore |
| Image Storage | Firebase Storage |
| CDN | Cloudflare |
| Domain | Custom domain |
| SSL | Automatic (Let's Encrypt) |
| CI/CD | GitHub Actions |

### Features
| Feature | Priority |
|---------|----------|
| Public URL (anyone can access) | Critical |
| Mobile PWA (installable) | High |
| Offline mode | Medium |
| Push notifications | Low |

---

## Version 6.0 — AI Enhancement 🤖
**Target: Future**

| Feature | Priority |
|---------|----------|
| Better Hebrew AI (larger model) | High |
| Shopping list from recipe | High |
| Weekly meal planner | High |
| Nutritional information | Medium |
| Recipe recommendations | Medium |
| "What can I cook?" (ingredients → recipes) | High |
| Recipe scaling AI | Medium |
| Substitution suggestions | Medium |

---

## Vibe Developer Course Progress

| Step | Description | Status |
|------|-------------|--------|
| 1 | Set Up Workspace | ✅ Done |
| 2 | Install Claude Code | ✅ Done |
| 3 | Connect GitHub | ✅ Done |
| 4 | Create First Project | ✅ Done (and then some!) |
| 5 | Save to GitHub | ✅ Done |
| 6 | Iterate With Claude | ✅ Done (ongoing) |
| 7 | Publish to World | ⏳ Planned v5.0 |

---

## Technical Debt

| Item | Impact | Effort |
|------|--------|--------|
| Add .gitignore | Low | 5 min |
| Environment variables for config | Medium | 30 min |
| Input validation/sanitization | High | 2 hours |
| Error boundaries in UI | Medium | 1 hour |
| TypeScript for server.js | Low | 2 hours |
| Compress images before storage | Medium | 1 hour |
| Pagination for large recipe lists | Medium | 2 hours |

---

## Key Decisions Log

| Decision | Reasoning | Date |
|----------|-----------|------|
| Single HTML file | Simplicity, portability | Session 1 |
| Local AI (Ollama) | Privacy, no cloud cost | Session 3 |
| Flat file DB (JSON) | Simple, works offline | Session 1 |
| Node.js over Python | Better proxy support | Session 3 |
| Mistral 7B | Balance: quality vs RAM | Session 3 |
| Test suite with AI judge | Quality assurance | Session 4 |
| 4 development rules | Process improvement | Session 5 |
