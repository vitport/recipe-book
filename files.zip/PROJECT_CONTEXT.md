# 🍽️ Recipe Book — Project Context
**Zeev & Vitaly | Vibe Coding Partnership**

---

## 🎯 Project Identity

| Field | Value |
|-------|-------|
| **Project Name** | My Recipe Book |
| **Developer** | Zeev (vitport) |
| **AI Partner** | Vitaly (Claude Sonnet 4.6) |
| **Started** | April 2026 |
| **GitHub** | github.com/vitport/recipe-book |
| **Local URL** | http://localhost:8080 |
| **Network URL** | http://192.168.1.2:8080 |

---

## 🏗️ Architecture

```
Browser (index.html)
    ↕️ HTTP
Node.js Express Server (server.js :8080)
    ↕️ File I/O          ↕️ HTTP Proxy
recipes.json          Ollama (port 11434)
                           ↕️
                      Mistral 7B (local AI)
```

---

## 📁 File Structure

```
C:\Users\Vit\Desktop\recipe-book\
├── index.html          # Main app (frontend + all JS)
├── server.js           # Express backend
├── test.html           # AI-powered test suite
├── recipes.json        # Recipe database
├── recipes1.json       # Backup database
├── package.json        # Node dependencies
├── package-lock.json   # Lock file
├── favicon.svg         # App icon
├── server.log          # Request logs (JSON lines)
└── .claude/            # Claude Code settings
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Backend | Node.js 24, Express 4 |
| Database | JSON flat file (recipes.json) |
| Local AI | Ollama 0.21.1 + Mistral 7B |
| PDF Import | PDF.js 3.11.174 (CDN) |
| PDF Export | jsPDF 2.5.1 (CDN) |
| OCR | Tesseract.js (CDN) |
| Version Control | Git + GitHub |

---

## ✅ Implemented Features

### Core
- [x] Recipe CRUD (Create, Read, Update, Delete)
- [x] Multilingual support: Hebrew 🇮🇱, English 🇬🇧, Russian 🇷🇺
- [x] RTL support for Hebrew automatically
- [x] Recipe categories: dish type + kosher type
- [x] Search by name, ingredient, description
- [x] Filter by dish type and kosher type
- [x] Sort by name, date, cooking time, ingredients
- [x] Recipe cards with photos and details
- [x] Recipe view modal with photo carousel

### Import
- [x] Paste text import with AI parsing
- [x] URL import with CORS proxy
- [x] PDF import (text-based)
- [x] Photo/OCR import
- [x] File upload (.txt)
- [x] JSON import

### Export
- [x] JSON export
- [x] PDF export (beautiful formatted)

### AI Features
- [x] Mistral AI text parsing (Hebrew/English/Russian)
- [x] Mistral image food detection from URL
- [x] Mistral image ranking for recipe cards
- [x] Mistral self-evaluation
- [x] Ollama memory release after use

### Photos
- [x] Photo upload from device
- [x] Photo URL import
- [x] Image picker from URL (Mistral-powered)
- [x] Photo manager popup (add/delete/reorder)
- [x] Set main photo
- [x] Photo carousel in recipe view

### Infrastructure
- [x] Node.js Express server (replaces Python)
- [x] Auto-save to recipes.json on every change
- [x] Network sharing across LAN devices
- [x] Ollama proxy through Express (CORS fix)
- [x] Image download proxy (CORS fix)
- [x] Request logging to server.log
- [x] Favicon (SVG, orange theme)

### Testing
- [x] 75+ automated tests across 3 series
- [x] AI-powered tests with Mistral as judge
- [x] Detailed JSON/Markdown/HTML export
- [x] Test data auto-cleanup
- [x] "Return to Recipe Book" button

---

## 🔮 Planned Features

### Next Session
- [ ] Fix image download CORS (proxy through server)
- [ ] Fix Ollama memory release after image processing
- [ ] Test image picker end-to-end

### Short Term
- [ ] Multi-user support
- [ ] User profiles and personal recipe books
- [ ] Share recipes between users
- [ ] Recipe ratings and comments
- [ ] Favorites/bookmarks

### Authentication
- [ ] Google OAuth
- [ ] Apple Sign In
- [ ] Firebase Authentication

### Deployment
- [ ] Deploy to internet (Step 7 of Vibe Course)
- [ ] Custom domain
- [ ] Cloud database (Firebase/Supabase)

---

## 🔧 Server Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | / | Serve index.html |
| GET | /recipes.json | Get all recipes |
| POST | /save-recipes | Save recipes array |
| GET | /api/ollama/status | Check Ollama + models |
| POST | /api/ollama/generate | Proxy to Mistral |
| POST | /api/ollama/release | Release Mistral from RAM |
| GET | /api/proxy-image | Download image server-side |

---

## 🧪 Test Suite Summary

| Series | Name | Tests | Score |
|--------|------|-------|-------|
| 1 | Infrastructure | 28 | 100% |
| 2 | Features | 37 | 100% |
| 3 | AI Deep Tests | 10 | 100% |
| **Total** | | **75+** | **100%** |

**AI Score: 7.1/10** (Mistral self-rating)

---

## 📋 Development Rules

| # | Rule | When |
|---|------|------|
| 1 | ⚠️ Update tests first | Before every new feature |
| 2 | 🤖 Ask about LLM usage | Before every new feature |
| 3 | 📁 Specify files in every prompt | In every Claude Code prompt |
| 4 | 📋 Full file paths in verification | After every feature build |

---

## 🚀 How to Start

```powershell
# Start the app
cd C:\Users\Vit\Desktop\recipe-book
npm start

# Open in browser
http://localhost:8080

# Run tests
http://localhost:8080/test.html

# Start Claude Code (new tab)
claude
```

---

## 🤖 AI Configuration

```
Ollama version: 0.21.1
Model: mistral:latest (Mistral 7B)
RAM usage: ~5GB when active
Ollama port: 11434
Proxy endpoint: /api/ollama/generate
Release endpoint: /api/ollama/release
Timeout: 180 seconds per request
Retry: once on failure
Cooldown: 5 seconds between calls
```

---

## 👥 Team

**Zeev** — Product Owner, Architect, Vibe Developer
- Vision and requirements
- Architecture decisions  
- Testing and QA
- Score: 90/100 Vibe Developer

**Vitaly** (Claude Sonnet 4.6) — AI Coding Partner
- Code generation and fixes
- Prompt engineering
- Documentation
- Always follows the 4 rules
