# 📋 Product Requirements Document (PRD)
**My Recipe Book | Version 2.0**
*Zeev & Vitaly | April 2026*

---

## 1. Executive Summary

My Recipe Book is a multilingual, AI-powered personal recipe management web application. It enables users to collect, organize, and access recipes in Hebrew, English, and Russian from multiple sources (URL, PDF, photo, text) using local AI (Mistral) for intelligent parsing and image selection.

The application runs locally on a home network, sharing recipes across all devices, with plans to deploy publicly with multi-user authentication.

---

## 2. Problem Statement

Home cooks who collect recipes from multiple sources (Israeli cooking websites, Russian recipe books, English food blogs) face a fragmented experience:

- Recipes scattered across browser bookmarks, photos, PDFs, WhatsApp messages
- No single app supports Hebrew RTL properly alongside English and Russian
- Manual copy-paste is tedious and loses formatting
- No intelligent parsing that understands recipe structure across languages
- Sharing recipes between family members requires manual export/import

---

## 3. Target Users

### Primary User: Zeev
- Home cook collecting recipes in Hebrew, Russian, English
- Tech-savvy, comfortable with local apps
- Wants AI assistance without cloud dependency
- Values privacy — prefers local AI over cloud AI

### Secondary Users: Family Members
- Access app via home network (192.168.1.x)
- Less technical — need simple UI
- Mobile and desktop access

---

## 4. Core User Stories

### Import
- As a user, I want to paste a recipe URL and have AI extract all recipe details automatically
- As a user, I want to upload a PDF recipe book and import individual recipes
- As a user, I want to photograph a handwritten recipe and have it converted to text
- As a user, I want to paste copied recipe text and have AI structure it properly
- As a user, I want AI to find and rank food images from recipe URLs

### Manage
- As a user, I want to organize recipes by dish type and kosher type
- As a user, I want to search recipes by name, ingredient, or description
- As a user, I want to sort recipes by various criteria
- As a user, I want to manage multiple photos per recipe
- As a user, I want to edit any recipe field at any time

### Share
- As a user, I want all family devices to see the same recipes
- As a user, I want to export a recipe as a beautiful PDF
- As a user, I want to share my recipe collection via JSON

### Quality
- As a user, I want to know the app is working correctly (test suite)
- As a user, I want AI to validate recipe quality

---

## 5. Functional Requirements

### 5.1 Recipe Management
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-01 | Create recipes manually via editor | Must Have |
| FR-02 | Edit all recipe fields | Must Have |
| FR-03 | Delete recipes with confirmation | Must Have |
| FR-04 | View recipes in full-screen modal | Must Have |
| FR-05 | Support multiple photos per recipe | Must Have |
| FR-06 | Auto-save to server after every change | Must Have |

### 5.2 Import
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-10 | Import from URL via CORS proxy | Must Have |
| FR-11 | Import from PDF (text-based) | Must Have |
| FR-12 | Import from photo via OCR | Must Have |
| FR-13 | Import from pasted text | Must Have |
| FR-14 | AI parsing for Hebrew/English/Russian | Must Have |
| FR-15 | Image picker with Mistral food detection | Should Have |
| FR-16 | Image download via server proxy | Should Have |

### 5.3 Organization
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-20 | Filter by dish type (8 types) | Must Have |
| FR-21 | Filter by kosher type (4 types) | Must Have |
| FR-22 | Full-text search | Must Have |
| FR-23 | Sort by 6 criteria | Should Have |
| FR-24 | Recipe count display | Nice to Have |

### 5.4 AI Features
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-30 | Local AI via Ollama + Mistral | Must Have |
| FR-31 | Recipe text parsing in 3 languages | Must Have |
| FR-32 | Food image detection and ranking | Should Have |
| FR-33 | Fallback to manual parser if AI unavailable | Must Have |
| FR-34 | Memory release after AI use | Should Have |

### 5.5 Network
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-40 | Serve on local network (LAN) | Must Have |
| FR-41 | Auto-sync recipes across devices | Must Have |
| FR-42 | Proxy external requests server-side | Must Have |

---

## 6. Non-Functional Requirements

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-01 | Page load time | < 2 seconds |
| NFR-02 | Server response time | < 1000ms |
| NFR-03 | AI parsing time | < 180 seconds |
| NFR-04 | Test suite pass rate | 100% |
| NFR-05 | Hebrew RTL rendering | Perfect |
| NFR-06 | Mobile responsive | Yes |
| NFR-07 | Works offline (except AI) | Yes |

---

## 7. Future Requirements (v3.0)

### Multi-User
- User accounts with individual recipe collections
- Shared family recipe pool
- Recipe sharing between users
- Comments and ratings

### Authentication
- Google OAuth 2.0
- Apple Sign In
- Firebase Authentication
- Session management

### Cloud Deployment
- Deploy to Vercel/Railway/Fly.io
- Cloud database (Firebase/Supabase)
- CDN for images
- Custom domain

---

## 8. Constraints

- **Privacy**: Local AI only, no cloud AI for recipe data
- **Cost**: Free tools only (Ollama, open source)
- **Language**: Must support Hebrew RTL perfectly
- **Network**: Must work on local LAN without internet (except AI CDN)

---

## 9. Success Metrics

| Metric | Current | Target |
|--------|---------|--------|
| Test pass rate | 100% | 100% |
| AI quality score | 7.1/10 | 8.5/10 |
| Import success rate | ~80% | 95% |
| Page load time | 20ms | < 500ms |
| Languages supported | 3 | 3+ |
